document.addEventListener("DOMContentLoaded", function() {
    calculate();
  });



function calculate(){
    var n1 = document.getElementById("no1").value;
    var n2 = document.getElementById("no2").value;
    var n3 = document.getElementById("no3").value;
    var sub = 0;
    var tot = 0;
    var subpos = document.getElementById("sub");
    var totpos = document.getElementById("tot");
    subpos.textContent="";
    totpos.textContent="";

    sub = n1*450 + n2*390 + n3*420;
    tot = sub + 40;
    var subb = document.createTextNode(sub);
    var tott = document.createTextNode(tot);
    subpos.appendChild(subb);
    totpos.appendChild(tott);


}

function remove( x ){
    var item = document.getElementById("it"+x);
    var pos = document.getElementById("fake");
    var neww = document.createElement("input");
    neww.id = "no"+x;
    pos.hidden=true;
    pos.appendChild(neww);
    document.getElementById("no"+x).value = 0 ;
    item.textContent="";
    
}
function removeall(){
    for(var x=1 ; x<4;x++){
        var item = document.getElementById("it"+x);
        document.getElementById("no"+x).value = 0 ;
        item.textContent="";
    }
    
    
}