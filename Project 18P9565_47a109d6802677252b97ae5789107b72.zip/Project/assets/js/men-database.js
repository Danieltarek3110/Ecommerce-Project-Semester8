
    document.addEventListener("DOMContentLoaded", function() {
      insert();
    });

function insert(){
    var position = document.getElementById("products");

    for(var i =0 ; i<item.length ; i++){
      //First Div
    var cont = document.createElement("div");
    cont.className ="col-md-4";
    cont.id = item[i].itemId;
    //2nd div
    var prod = document.createElement("div");
    prod.className ="product-item";
    //Product image
    var aaa = document.createElement("a");
    var pic = document.createElement("img");
    pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
    //Down Content div
    var down = document.createElement("div");
    down.className ="down-content";
    //Product name
    var aa = document.createElement("a");
    var tit = document.createElement("h4");
    titname = document.createTextNode(item[i].itemName);
    tit.appendChild(titname);
    //Product price
    var price = document.createElement("h6");
    var priceee = document.createTextNode(item[i].itemPrice + " EGP");
    price.appendChild(priceee);
    //product description
    var pp = document.createElement("p");
    var des = document.createTextNode(item[i].itemDesc);
    pp.appendChild(des);
    // Product reviews no
    var sp = document.createElement("span");
    var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
    sp.appendChild(rev);

    //Add to cart div
    var cart = document.createElement("div");
    cart.className ="addcart";
    // Sizes div
    var siz = document.createElement("div");
    //select
    var select =  document.createElement("select");
    select.name = "Size";

    //options
    var opt =  document.createElement("option");
      opt.value = "";
      opt.selected = true;
      opt.disabled = true;
      opt.hidden = true;
      var sizeVal = document.createTextNode("Sizes");
      opt.appendChild(sizeVal);
      select.appendChild(opt);
    for(var j =0 ; j<item[i].itemSizes.length ; j++){
      var opt =  document.createElement("option");
      var sizee = item[i].itemSizes[j];
      opt.value = sizee;
      var sizeVal = document.createTextNode(sizee);
      opt.appendChild(sizeVal);
      select.appendChild(opt);

    }

    //Add button
    var butt = document.createElement("button");
    butt.type = "button";
    var addca = document.createTextNode("Add to Cart");
    butt.appendChild(addca)
    butt.value= "Add to Cart";
    butt.className= "addcart";



    aa.appendChild(tit);
    aaa.appendChild(pic);
    prod.appendChild(aaa);
    down.appendChild(aa);
    down.appendChild(price);
    down.appendChild(des);
    down.appendChild(sp);
    siz.appendChild(select);
    
    cart.appendChild(siz);
    cart.appendChild(butt);
    

    prod.appendChild(down);
    prod.appendChild(cart);
    cont.appendChild(prod);
    position.appendChild(cont);
    }
    


    
    
    
}




function filter(){
  var pricerange = document.getElementById("fprice").value ;
  var selectedfit = document.getElementById("filterselected") ;
  var position = document.getElementById("products");
  position.textContent= "";
  selectedfit.textContent= "";
  if(pricerange==350){
    var filt_text = document.createTextNode("Price : 0-350 EGP");
    selectedfit.appendChild(filt_text);
    document.getElementById("fcat").value= "Category";
    document.getElementById("fprice").value= "Price";
  }
  for(var i =0 ; i<item.length ; i++){
    if(pricerange==350){
      if(item[i].itemPrice<350){
        //First Div
      var cont = document.createElement("div");
      cont.className ="col-md-4";
      cont.id = item[i].itemId;
      //2nd div
      var prod = document.createElement("div");
      prod.className ="product-item";
      //Product image
      var aaa = document.createElement("a");
      var pic = document.createElement("img");
      pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
      //Down Content div
      var down = document.createElement("div");
      down.className ="down-content";
      //Product name
      var aa = document.createElement("a");
      var tit = document.createElement("h4");
      titname = document.createTextNode(item[i].itemName);
      tit.appendChild(titname);
      //Product price
      var price = document.createElement("h6");
      var priceee = document.createTextNode(item[i].itemPrice + " EGP");
      price.appendChild(priceee);
      //product description
      var pp = document.createElement("p");
      var des = document.createTextNode(item[i].itemDesc);
      pp.appendChild(des);
      // Product reviews no
      var sp = document.createElement("span");
      var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
      sp.appendChild(rev);
  
      //Add to cart div
      var cart = document.createElement("div");
      cart.className ="addcart";
      // Sizes div
      var siz = document.createElement("div");
      //select
      var select =  document.createElement("select");
      select.name = "Size";
  
      //options
      var opt =  document.createElement("option");
        opt.value = "";
        opt.selected = true;
        opt.disabled = true;
        opt.hidden = true;
        var sizeVal = document.createTextNode("Sizes");
        opt.appendChild(sizeVal);
        select.appendChild(opt);
      for(var j =0 ; j<item[i].itemSizes.length ; j++){
        var opt =  document.createElement("option");
        var sizee = item[i].itemSizes[j];
        opt.value = sizee;
        var sizeVal = document.createTextNode(sizee);
        opt.appendChild(sizeVal);
        select.appendChild(opt);
  
      }
  
      //Add button
      var butt = document.createElement("button");
      butt.type = "button";
      var addca = document.createTextNode("Add to Cart");
      butt.appendChild(addca)
      butt.value= "Add to Cart";
      butt.className= "addcart";
  
  
  
      aa.appendChild(tit);
      aaa.appendChild(pic);
      prod.appendChild(aaa);
      down.appendChild(aa);
      down.appendChild(price);
      down.appendChild(des);
      down.appendChild(sp);
      siz.appendChild(select);
      
      cart.appendChild(siz);
      cart.appendChild(butt);
      
  
      prod.appendChild(down);
      prod.appendChild(cart);
      cont.appendChild(prod);
      position.appendChild(cont);
      }

    }
    
  }
  



  if(pricerange==449){
    var filt_text = document.createTextNode("Price : 350-450 EGP");
    selectedfit.appendChild(filt_text);
    document.getElementById("fcat").value= "Category";
    document.getElementById("fprice").value= "Price";
  }
  for(var i =0 ; i<item.length ; i++){
    if(pricerange==449){
      if(item[i].itemPrice>350 && item[i].itemPrice<450 ){
        //First Div
      var cont = document.createElement("div");
      cont.className ="col-md-4";
      cont.id = item[i].itemId;
      //2nd div
      var prod = document.createElement("div");
      prod.className ="product-item";
      //Product image
      var aaa = document.createElement("a");
      var pic = document.createElement("img");
      pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
      //Down Content div
      var down = document.createElement("div");
      down.className ="down-content";
      //Product name
      var aa = document.createElement("a");
      var tit = document.createElement("h4");
      titname = document.createTextNode(item[i].itemName);
      tit.appendChild(titname);
      //Product price
      var price = document.createElement("h6");
      var priceee = document.createTextNode(item[i].itemPrice + " EGP");
      price.appendChild(priceee);
      //product description
      var pp = document.createElement("p");
      var des = document.createTextNode(item[i].itemDesc);
      pp.appendChild(des);
      // Product reviews no
      var sp = document.createElement("span");
      var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
      sp.appendChild(rev);
  
      //Add to cart div
      var cart = document.createElement("div");
      cart.className ="addcart";
      // Sizes div
      var siz = document.createElement("div");
      //select
      var select =  document.createElement("select");
      select.name = "Size";
  
      //options
      var opt =  document.createElement("option");
        opt.value = "";
        opt.selected = true;
        opt.disabled = true;
        opt.hidden = true;
        var sizeVal = document.createTextNode("Sizes");
        opt.appendChild(sizeVal);
        select.appendChild(opt);
      for(var j =0 ; j<item[i].itemSizes.length ; j++){
        var opt =  document.createElement("option");
        var sizee = item[i].itemSizes[j];
        opt.value = sizee;
        var sizeVal = document.createTextNode(sizee);
        opt.appendChild(sizeVal);
        select.appendChild(opt);
  
      }
  
      //Add button
      var butt = document.createElement("button");
      butt.type = "button";
      var addca = document.createTextNode("Add to Cart");
      butt.appendChild(addca)
      butt.value= "Add to Cart";
      butt.className= "addcart";
  
  
  
      aa.appendChild(tit);
      aaa.appendChild(pic);
      prod.appendChild(aaa);
      down.appendChild(aa);
      down.appendChild(price);
      down.appendChild(des);
      down.appendChild(sp);
      siz.appendChild(select);
      
      cart.appendChild(siz);
      cart.appendChild(butt);
      
  
      prod.appendChild(down);
      prod.appendChild(cart);
      cont.appendChild(prod);
      position.appendChild(cont);
      }

    }
    
  }

  if(pricerange==450){
    var filt_text = document.createTextNode("Price : 450-600 EGP");
    selectedfit.appendChild(filt_text);
    document.getElementById("fcat").value= "Category";
    document.getElementById("fprice").value= "Price";
  }
  for(var i =0 ; i<item.length ; i++){
    if(pricerange==450){
      if(item[i].itemPrice>449 ){
        //First Div
      var cont = document.createElement("div");
      cont.className ="col-md-4";
      cont.id = item[i].itemId;
      //2nd div
      var prod = document.createElement("div");
      prod.className ="product-item";
      //Product image
      var aaa = document.createElement("a");
      var pic = document.createElement("img");
      pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
      //Down Content div
      var down = document.createElement("div");
      down.className ="down-content";
      //Product name
      var aa = document.createElement("a");
      var tit = document.createElement("h4");
      titname = document.createTextNode(item[i].itemName);
      tit.appendChild(titname);
      //Product price
      var price = document.createElement("h6");
      var priceee = document.createTextNode(item[i].itemPrice + " EGP");
      price.appendChild(priceee);
      //product description
      var pp = document.createElement("p");
      var des = document.createTextNode(item[i].itemDesc);
      pp.appendChild(des);
      // Product reviews no
      var sp = document.createElement("span");
      var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
      sp.appendChild(rev);
  
      //Add to cart div
      var cart = document.createElement("div");
      cart.className ="addcart";
      // Sizes div
      var siz = document.createElement("div");
      //select
      var select =  document.createElement("select");
      select.name = "Size";
  
      //options
      var opt =  document.createElement("option");
        opt.value = "";
        opt.selected = true;
        opt.disabled = true;
        opt.hidden = true;
        var sizeVal = document.createTextNode("Sizes");
        opt.appendChild(sizeVal);
        select.appendChild(opt);
      for(var j =0 ; j<item[i].itemSizes.length ; j++){
        var opt =  document.createElement("option");
        var sizee = item[i].itemSizes[j];
        opt.value = sizee;
        var sizeVal = document.createTextNode(sizee);
        opt.appendChild(sizeVal);
        select.appendChild(opt);
  
      }
  
      //Add button
      var butt = document.createElement("button");
      butt.type = "button";
      var addca = document.createTextNode("Add to Cart");
      butt.appendChild(addca)
      butt.value= "Add to Cart";
      butt.className= "addcart";
  
  
  
      aa.appendChild(tit);
      aaa.appendChild(pic);
      prod.appendChild(aaa);
      down.appendChild(aa);
      down.appendChild(price);
      down.appendChild(des);
      down.appendChild(sp);
      siz.appendChild(select);
      
      cart.appendChild(siz);
      cart.appendChild(butt);
      
  
      prod.appendChild(down);
      prod.appendChild(cart);
      cont.appendChild(prod);
      position.appendChild(cont);
      }

    }
    
  }


  var categ = document.getElementById("fcat").value ;

  if(categ == "Tshirt"){
    var filt_text = document.createTextNode("Category: Tshirt");
    selectedfit.appendChild(filt_text);
    document.getElementById("fcat").value= "Category";
    document.getElementById("fprice").value= "Price";
  }
  for(var i =0 ; i<item.length ; i++){
    if(categ =="Tshirt"){
      if(item[i].itemCat==1){
        //First Div
      var cont = document.createElement("div");
      cont.className ="col-md-4";
      cont.id = item[i].itemId;
      //2nd div
      var prod = document.createElement("div");
      prod.className ="product-item";
      //Product image
      var aaa = document.createElement("a");
      var pic = document.createElement("img");
      pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
      //Down Content div
      var down = document.createElement("div");
      down.className ="down-content";
      //Product name
      var aa = document.createElement("a");
      var tit = document.createElement("h4");
      titname = document.createTextNode(item[i].itemName);
      tit.appendChild(titname);
      //Product price
      var price = document.createElement("h6");
      var priceee = document.createTextNode(item[i].itemPrice + " EGP");
      price.appendChild(priceee);
      //product description
      var pp = document.createElement("p");
      var des = document.createTextNode(item[i].itemDesc);
      pp.appendChild(des);
      // Product reviews no
      var sp = document.createElement("span");
      var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
      sp.appendChild(rev);
  
      //Add to cart div
      var cart = document.createElement("div");
      cart.className ="addcart";
      // Sizes div
      var siz = document.createElement("div");
      //select
      var select =  document.createElement("select");
      select.name = "Size";
  
      //options
      var opt =  document.createElement("option");
        opt.value = "";
        opt.selected = true;
        opt.disabled = true;
        opt.hidden = true;
        var sizeVal = document.createTextNode("Sizes");
        opt.appendChild(sizeVal);
        select.appendChild(opt);
      for(var j =0 ; j<item[i].itemSizes.length ; j++){
        var opt =  document.createElement("option");
        var sizee = item[i].itemSizes[j];
        opt.value = sizee;
        var sizeVal = document.createTextNode(sizee);
        opt.appendChild(sizeVal);
        select.appendChild(opt);
  
      }
  
      //Add button
      var butt = document.createElement("button");
      butt.type = "button";
      var addca = document.createTextNode("Add to Cart");
      butt.appendChild(addca)
      butt.value= "Add to Cart";
      butt.className= "addcart";
  
  
  
      aa.appendChild(tit);
      aaa.appendChild(pic);
      prod.appendChild(aaa);
      down.appendChild(aa);
      down.appendChild(price);
      down.appendChild(des);
      down.appendChild(sp);
      siz.appendChild(select);
      
      cart.appendChild(siz);
      cart.appendChild(butt);
      
  
      prod.appendChild(down);
      prod.appendChild(cart);
      cont.appendChild(prod);
      position.appendChild(cont);
      }

    }
    
  }
  
  if(categ == "Pants"){
    var filt_text = document.createTextNode("Category: Pants");
    selectedfit.appendChild(filt_text);
    document.getElementById("fcat").value= "Category";
    document.getElementById("fprice").value= "Price";
  }
  for(var i =0 ; i<item.length ; i++){
    if(categ =="Pants"){
      if(item[i].itemCat==2){
        //First Div
      var cont = document.createElement("div");
      cont.className ="col-md-4";
      cont.id = item[i].itemId;
      //2nd div
      var prod = document.createElement("div");
      prod.className ="product-item";
      //Product image
      var aaa = document.createElement("a");
      var pic = document.createElement("img");
      pic.src ="assets/images/product_0"+(3+item[i].itemId)+".jpg";
      //Down Content div
      var down = document.createElement("div");
      down.className ="down-content";
      //Product name
      var aa = document.createElement("a");
      var tit = document.createElement("h4");
      titname = document.createTextNode(item[i].itemName);
      tit.appendChild(titname);
      //Product price
      var price = document.createElement("h6");
      var priceee = document.createTextNode(item[i].itemPrice + " EGP");
      price.appendChild(priceee);
      //product description
      var pp = document.createElement("p");
      var des = document.createTextNode(item[i].itemDesc);
      pp.appendChild(des);
      // Product reviews no
      var sp = document.createElement("span");
      var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
      sp.appendChild(rev);
  
      //Add to cart div
      var cart = document.createElement("div");
      cart.className ="addcart";
      // Sizes div
      var siz = document.createElement("div");
      //select
      var select =  document.createElement("select");
      select.name = "Size";
  
      //options
      var opt =  document.createElement("option");
        opt.value = "";
        opt.selected = true;
        opt.disabled = true;
        opt.hidden = true;
        var sizeVal = document.createTextNode("Sizes");
        opt.appendChild(sizeVal);
        select.appendChild(opt);
      for(var j =0 ; j<item[i].itemSizes.length ; j++){
        var opt =  document.createElement("option");
        var sizee = item[i].itemSizes[j];
        opt.value = sizee;
        var sizeVal = document.createTextNode(sizee);
        opt.appendChild(sizeVal);
        select.appendChild(opt);
  
      }
  
      //Add button
      var butt = document.createElement("button");
      butt.type = "button";
      var addca = document.createTextNode("Add to Cart");
      butt.appendChild(addca)
      butt.value= "Add to Cart";
      butt.className= "addcart";
  
  
  
      aa.appendChild(tit);
      aaa.appendChild(pic);
      prod.appendChild(aaa);
      down.appendChild(aa);
      down.appendChild(price);
      down.appendChild(des);
      down.appendChild(sp);
      siz.appendChild(select);
      
      cart.appendChild(siz);
      cart.appendChild(butt);
      
  
      prod.appendChild(down);
      prod.appendChild(cart);
      cont.appendChild(prod);
      position.appendChild(cont);
      }

    }
    
  }
  



  
  

  
}
  





//items
item=[{
  itemId: 1,
  itemName:'Printed T-Shirt',
  itemDesc:'Printed pattern T-shirt.',
  itemPrice: 450,
  itemReviews: 43,
  itemSizes:['S','M','L'],
  itemCat: 1
  },

  {
    itemId: 2,
    itemName:'V-neck T-Shirt',
    itemDesc:'V-neck T-Shirt for men.',
    itemPrice: 380,
    itemReviews: 73,
    itemSizes:['M','L'],
    itemCat: 1
    },

  {
    itemId: 3,
    itemName:'Plain T-Shirt',
    itemDesc:'Plain Orange T-Shirt.',
    itemPrice: 290,
    itemReviews: 18,
    itemSizes:['XS','M','XL'],
    itemCat: 1
    },

  {
    itemId: 4,
    itemName:'Black Pants',
    itemDesc:'Black pants for men.',
    itemPrice: 470,
    itemReviews: 38,
    itemSizes:['XL'],
    itemCat: 2
    },

  {
    itemId: 5,
    itemName:'Grey Pants',
    itemDesc:'Grey pants for men.',
    itemPrice: 425,
    itemReviews: 15,
    itemSizes:['S','M','L'],
    itemCat: 2
    },

  {
    itemId: 6,
    itemName:'Beige Pants',
    itemDesc:'Beige pants for men.',
    itemPrice: 410,
    itemReviews: 7,
    itemSizes:[],
    itemCat: 2
    },

  {
    itemId: 7,
    itemName:'Plain Blue T-Shirt',
    itemDesc:'Plain Blue Men T-Shirt.',
    itemPrice: 270,
    itemReviews: 61,
    itemSizes:['XS','M','XL'],
    itemCat: 1
    
    },

  {
    itemId: 8,
    itemName:'Blue Striped T-Shirt',
    itemDesc:'Blue Striped T-Shirt',
    itemPrice: 310,
    itemReviews: 22,
    itemSizes:['S','XL'],
    itemCat: 1
    
  },


  {
    itemId: 9,
    itemName:'Red & Grey T-Shirt',
    itemDesc:'Red & Grey T-Shirt',
    itemPrice: 350,
    itemReviews: 42,
    itemSizes:['S','M'],
    itemCat: 1
    
  },


  {
    itemId: 10,
    itemName:'Grey Pants',
    itemDesc:'Grey Pants for Men',
    itemPrice: 550,
    itemReviews: 31,
    itemSizes:['XS','S','L'],
    itemCat: 2
    
  },
];
