function newsl(){
    
    let name = document.getElementById('name1').value;
    let email = document.getElementById('email1').value;
    newtitle = document.createElement('h1') ;
    newpara = document.createElement('p')
    title = document.createTextNode('Thank you, '+ name);
    para =  document.createTextNode('The promocode is sent to your email  ' + email+ ' . ');

    newtitle.appendChild(title);
    newpara.appendChild(para);
    document.getElementById('thank').appendChild(newtitle);
    document.getElementById('thank').appendChild(newpara);

    document.getElementById("name1").value = "";
    document.getElementById("email1").value = "";
}

function msg1(){
    
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    newtitle1 = document.createElement('h1') ;
    newpara1 = document.createElement('p')
    title1 = document.createTextNode('Thank you, '+ name);
    para1 =  document.createTextNode('We have received your Message and will reply as soon as possible on: '+ email);

    newtitle1.appendChild(title1);
    newpara1.appendChild(para1);
    document.getElementById('thank1').appendChild(newtitle1);
    document.getElementById('thank1').appendChild(newpara1);


}

    
    
