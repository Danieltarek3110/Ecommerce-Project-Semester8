document.addEventListener("DOMContentLoaded", function() {
    insert();
  });

function insert(){
  var position = document.getElementById("products");

  for(var i =0 ; i<item.length ; i++){
    //First Div
  var cont = document.createElement("div");
  cont.className ="col-md-4";
  cont.id = item[i].itemId;
  //2nd div
  var prod = document.createElement("div");
  prod.className ="product-item";
  //Product image
  var aaa = document.createElement("a");
  var pic = document.createElement("img");
  pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
  //Down Content div
  var down = document.createElement("div");
  down.className ="down-content";
  //Product name
  var aa = document.createElement("a");
  var tit = document.createElement("h4");
  titname = document.createTextNode(item[i].itemName);
  tit.appendChild(titname);
  //Product price
  var price = document.createElement("h6");
  var priceee = document.createTextNode(item[i].itemPrice + " EGP");
  price.appendChild(priceee);
  //product description
  var pp = document.createElement("p");
  var des = document.createTextNode(item[i].itemDesc);
  pp.appendChild(des);
  // Product reviews no
  var sp = document.createElement("span");
  var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
  sp.appendChild(rev);

  //Add to cart div
  var cart = document.createElement("div");
  cart.className ="addcart";
  // Sizes div
  var siz = document.createElement("div");
  //select
  var select =  document.createElement("select");
  select.name = "Size";

  //options
  var opt =  document.createElement("option");
    opt.value = "";
    opt.selected = true;
    opt.disabled = true;
    opt.hidden = true;
    var sizeVal = document.createTextNode("Sizes");
    opt.appendChild(sizeVal);
    select.appendChild(opt);
  for(var j =0 ; j<item[i].itemSizes.length ; j++){
    var opt =  document.createElement("option");
    var sizee = item[i].itemSizes[j];
    opt.value = sizee;
    var sizeVal = document.createTextNode(sizee);
    opt.appendChild(sizeVal);
    select.appendChild(opt);

  }

  //Add button
  var butt = document.createElement("button");
  butt.type = "button";
  var addca = document.createTextNode("Add to Cart");
  butt.appendChild(addca)
  butt.value= "Add to Cart";
  butt.className= "addcart";



  aa.appendChild(tit);
  aaa.appendChild(pic);
  prod.appendChild(aaa);
  down.appendChild(aa);
  down.appendChild(price);
  down.appendChild(des);
  down.appendChild(sp);
  siz.appendChild(select);
  
  cart.appendChild(siz);
  cart.appendChild(butt);
  

  prod.appendChild(down);
  prod.appendChild(cart);
  cont.appendChild(prod);
  position.appendChild(cont);
  }
  


  
  
  
}



function filter(){
var pricerange = getElementById("fprice");
var value = 2;//pricerange.options[select.selectedIndex].value;
console.log(value);
}





function filter(){
    var pricerange = document.getElementById("fprice").value ;
    var selectedfit = document.getElementById("filterselected") ;
    var position = document.getElementById("products");
    position.textContent= "";
    selectedfit.textContent= "";
    if(pricerange==350){
      var filt_text = document.createTextNode("Price : 0-350 EGP");
      selectedfit.appendChild(filt_text);
      document.getElementById("fcat").value= "Category";
      document.getElementById("fprice").value= "Price";
    }
    for(var i =0 ; i<item.length ; i++){
      if(pricerange==350){
        if(item[i].itemPrice<350){
          //First Div
        var cont = document.createElement("div");
        cont.className ="col-md-4";
        cont.id = item[i].itemId;
        //2nd div
        var prod = document.createElement("div");
        prod.className ="product-item";
        //Product image
        var aaa = document.createElement("a");
        var pic = document.createElement("img");
        pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
        //Down Content div
        var down = document.createElement("div");
        down.className ="down-content";
        //Product name
        var aa = document.createElement("a");
        var tit = document.createElement("h4");
        titname = document.createTextNode(item[i].itemName);
        tit.appendChild(titname);
        //Product price
        var price = document.createElement("h6");
        var priceee = document.createTextNode(item[i].itemPrice + " EGP");
        price.appendChild(priceee);
        //product description
        var pp = document.createElement("p");
        var des = document.createTextNode(item[i].itemDesc);
        pp.appendChild(des);
        // Product reviews no
        var sp = document.createElement("span");
        var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
        sp.appendChild(rev);
    
        //Add to cart div
        var cart = document.createElement("div");
        cart.className ="addcart";
        // Sizes div
        var siz = document.createElement("div");
        //select
        var select =  document.createElement("select");
        select.name = "Size";
    
        //options
        var opt =  document.createElement("option");
          opt.value = "";
          opt.selected = true;
          opt.disabled = true;
          opt.hidden = true;
          var sizeVal = document.createTextNode("Sizes");
          opt.appendChild(sizeVal);
          select.appendChild(opt);
        for(var j =0 ; j<item[i].itemSizes.length ; j++){
          var opt =  document.createElement("option");
          var sizee = item[i].itemSizes[j];
          opt.value = sizee;
          var sizeVal = document.createTextNode(sizee);
          opt.appendChild(sizeVal);
          select.appendChild(opt);
    
        }
    
        //Add button
        var butt = document.createElement("button");
        butt.type = "button";
        var addca = document.createTextNode("Add to Cart");
        butt.appendChild(addca)
        butt.value= "Add to Cart";
        butt.className= "addcart";
    
    
    
        aa.appendChild(tit);
        aaa.appendChild(pic);
        prod.appendChild(aaa);
        down.appendChild(aa);
        down.appendChild(price);
        down.appendChild(des);
        down.appendChild(sp);
        siz.appendChild(select);
        
        cart.appendChild(siz);
        cart.appendChild(butt);
        
    
        prod.appendChild(down);
        prod.appendChild(cart);
        cont.appendChild(prod);
        position.appendChild(cont);
        }
  
      }
      
    }
    
  
  
  
    if(pricerange==449){
      var filt_text = document.createTextNode("Price : 350-450 EGP");
      selectedfit.appendChild(filt_text);
      document.getElementById("fcat").value= "Category";
      document.getElementById("fprice").value= "Price";
    }
    for(var i =0 ; i<item.length ; i++){
      if(pricerange==449){
        if(item[i].itemPrice>350 && item[i].itemPrice<450 ){
          //First Div
        var cont = document.createElement("div");
        cont.className ="col-md-4";
        cont.id = item[i].itemId;
        //2nd div
        var prod = document.createElement("div");
        prod.className ="product-item";
        //Product image
        var aaa = document.createElement("a");
        var pic = document.createElement("img");
        pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
        //Down Content div
        var down = document.createElement("div");
        down.className ="down-content";
        //Product name
        var aa = document.createElement("a");
        var tit = document.createElement("h4");
        titname = document.createTextNode(item[i].itemName);
        tit.appendChild(titname);
        //Product price
        var price = document.createElement("h6");
        var priceee = document.createTextNode(item[i].itemPrice + " EGP");
        price.appendChild(priceee);
        //product description
        var pp = document.createElement("p");
        var des = document.createTextNode(item[i].itemDesc);
        pp.appendChild(des);
        // Product reviews no
        var sp = document.createElement("span");
        var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
        sp.appendChild(rev);
    
        //Add to cart div
        var cart = document.createElement("div");
        cart.className ="addcart";
        // Sizes div
        var siz = document.createElement("div");
        //select
        var select =  document.createElement("select");
        select.name = "Size";
    
        //options
        var opt =  document.createElement("option");
          opt.value = "";
          opt.selected = true;
          opt.disabled = true;
          opt.hidden = true;
          var sizeVal = document.createTextNode("Sizes");
          opt.appendChild(sizeVal);
          select.appendChild(opt);
        for(var j =0 ; j<item[i].itemSizes.length ; j++){
          var opt =  document.createElement("option");
          var sizee = item[i].itemSizes[j];
          opt.value = sizee;
          var sizeVal = document.createTextNode(sizee);
          opt.appendChild(sizeVal);
          select.appendChild(opt);
    
        }
    
        //Add button
        var butt = document.createElement("button");
        butt.type = "button";
        var addca = document.createTextNode("Add to Cart");
        butt.appendChild(addca)
        butt.value= "Add to Cart";
        butt.className= "addcart";
    
    
    
        aa.appendChild(tit);
        aaa.appendChild(pic);
        prod.appendChild(aaa);
        down.appendChild(aa);
        down.appendChild(price);
        down.appendChild(des);
        down.appendChild(sp);
        siz.appendChild(select);
        
        cart.appendChild(siz);
        cart.appendChild(butt);
        
    
        prod.appendChild(down);
        prod.appendChild(cart);
        cont.appendChild(prod);
        position.appendChild(cont);
        }
  
      }
      
    }
  
    if(pricerange==450){
      var filt_text = document.createTextNode("Price : 450-600 EGP");
      selectedfit.appendChild(filt_text);
      document.getElementById("fcat").value= "Category";
      document.getElementById("fprice").value= "Price";
    }
    for(var i =0 ; i<item.length ; i++){
      if(pricerange==450){
        if(item[i].itemPrice>449 ){
          //First Div
        var cont = document.createElement("div");
        cont.className ="col-md-4";
        cont.id = item[i].itemId;
        //2nd div
        var prod = document.createElement("div");
        prod.className ="product-item";
        //Product image
        var aaa = document.createElement("a");
        var pic = document.createElement("img");
        pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
        //Down Content div
        var down = document.createElement("div");
        down.className ="down-content";
        //Product name
        var aa = document.createElement("a");
        var tit = document.createElement("h4");
        titname = document.createTextNode(item[i].itemName);
        tit.appendChild(titname);
        //Product price
        var price = document.createElement("h6");
        var priceee = document.createTextNode(item[i].itemPrice + " EGP");
        price.appendChild(priceee);
        //product description
        var pp = document.createElement("p");
        var des = document.createTextNode(item[i].itemDesc);
        pp.appendChild(des);
        // Product reviews no
        var sp = document.createElement("span");
        var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
        sp.appendChild(rev);
    
        //Add to cart div
        var cart = document.createElement("div");
        cart.className ="addcart";
        // Sizes div
        var siz = document.createElement("div");
        //select
        var select =  document.createElement("select");
        select.name = "Size";
    
        //options
        var opt =  document.createElement("option");
          opt.value = "";
          opt.selected = true;
          opt.disabled = true;
          opt.hidden = true;
          var sizeVal = document.createTextNode("Sizes");
          opt.appendChild(sizeVal);
          select.appendChild(opt);
        for(var j =0 ; j<item[i].itemSizes.length ; j++){
          var opt =  document.createElement("option");
          var sizee = item[i].itemSizes[j];
          opt.value = sizee;
          var sizeVal = document.createTextNode(sizee);
          opt.appendChild(sizeVal);
          select.appendChild(opt);
    
        }
    
        //Add button
        var butt = document.createElement("button");
        butt.type = "button";
        var addca = document.createTextNode("Add to Cart");
        butt.appendChild(addca)
        butt.value= "Add to Cart";
        butt.className= "addcart";
    
    
    
        aa.appendChild(tit);
        aaa.appendChild(pic);
        prod.appendChild(aaa);
        down.appendChild(aa);
        down.appendChild(price);
        down.appendChild(des);
        down.appendChild(sp);
        siz.appendChild(select);
        
        cart.appendChild(siz);
        cart.appendChild(butt);
        
    
        prod.appendChild(down);
        prod.appendChild(cart);
        cont.appendChild(prod);
        position.appendChild(cont);
        }
  
      }
      
    }
  
  
    var categ = document.getElementById("fcat").value ;
  
    if(categ == "Tshirt"){
      var filt_text = document.createTextNode("Category: Tshirt");
      selectedfit.appendChild(filt_text);
      document.getElementById("fcat").value= "Category";
      document.getElementById("fprice").value= "Price";
    }
    for(var i =0 ; i<item.length ; i++){
      if(categ =="Tshirt"){
        if(item[i].itemCat==1){
          //First Div
        var cont = document.createElement("div");
        cont.className ="col-md-4";
        cont.id = item[i].itemId;
        //2nd div
        var prod = document.createElement("div");
        prod.className ="product-item";
        //Product image
        var aaa = document.createElement("a");
        var pic = document.createElement("img");
        pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
        //Down Content div
        var down = document.createElement("div");
        down.className ="down-content";
        //Product name
        var aa = document.createElement("a");
        var tit = document.createElement("h4");
        titname = document.createTextNode(item[i].itemName);
        tit.appendChild(titname);
        //Product price
        var price = document.createElement("h6");
        var priceee = document.createTextNode(item[i].itemPrice + " EGP");
        price.appendChild(priceee);
        //product description
        var pp = document.createElement("p");
        var des = document.createTextNode(item[i].itemDesc);
        pp.appendChild(des);
        // Product reviews no
        var sp = document.createElement("span");
        var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
        sp.appendChild(rev);
    
        //Add to cart div
        var cart = document.createElement("div");
        cart.className ="addcart";
        // Sizes div
        var siz = document.createElement("div");
        //select
        var select =  document.createElement("select");
        select.name = "Size";
    
        //options
        var opt =  document.createElement("option");
          opt.value = "";
          opt.selected = true;
          opt.disabled = true;
          opt.hidden = true;
          var sizeVal = document.createTextNode("Sizes");
          opt.appendChild(sizeVal);
          select.appendChild(opt);
        for(var j =0 ; j<item[i].itemSizes.length ; j++){
          var opt =  document.createElement("option");
          var sizee = item[i].itemSizes[j];
          opt.value = sizee;
          var sizeVal = document.createTextNode(sizee);
          opt.appendChild(sizeVal);
          select.appendChild(opt);
    
        }
    
        //Add button
        var butt = document.createElement("button");
        butt.type = "button";
        var addca = document.createTextNode("Add to Cart");
        butt.appendChild(addca)
        butt.value= "Add to Cart";
        butt.className= "addcart";
    
    
    
        aa.appendChild(tit);
        aaa.appendChild(pic);
        prod.appendChild(aaa);
        down.appendChild(aa);
        down.appendChild(price);
        down.appendChild(des);
        down.appendChild(sp);
        siz.appendChild(select);
        
        cart.appendChild(siz);
        cart.appendChild(butt);
        
    
        prod.appendChild(down);
        prod.appendChild(cart);
        cont.appendChild(prod);
        position.appendChild(cont);
        }
  
      }
      
    }
    
    if(categ == "Pants"){
      var filt_text = document.createTextNode("Category: Pants");
      selectedfit.appendChild(filt_text);
      document.getElementById("fcat").value= "Category";
      document.getElementById("fprice").value= "Price";
    }
    for(var i =0 ; i<item.length ; i++){
      if(categ =="Pants"){
        if(item[i].itemCat==2){
          //First Div
        var cont = document.createElement("div");
        cont.className ="col-md-4";
        cont.id = item[i].itemId;
        //2nd div
        var prod = document.createElement("div");
        prod.className ="product-item";
        //Product image
        var aaa = document.createElement("a");
        var pic = document.createElement("img");
        pic.src ="assets/images/wproduct_0"+(item[i].itemId)+".jpg";
        //Down Content div
        var down = document.createElement("div");
        down.className ="down-content";
        //Product name
        var aa = document.createElement("a");
        var tit = document.createElement("h4");
        titname = document.createTextNode(item[i].itemName);
        tit.appendChild(titname);
        //Product price
        var price = document.createElement("h6");
        var priceee = document.createTextNode(item[i].itemPrice + " EGP");
        price.appendChild(priceee);
        //product description
        var pp = document.createElement("p");
        var des = document.createTextNode(item[i].itemDesc);
        pp.appendChild(des);
        // Product reviews no
        var sp = document.createElement("span");
        var rev = document.createTextNode("Review(" + item[i].itemReviews +")");
        sp.appendChild(rev);
    
        //Add to cart div
        var cart = document.createElement("div");
        cart.className ="addcart";
        // Sizes div
        var siz = document.createElement("div");
        //select
        var select =  document.createElement("select");
        select.name = "Size";
    
        //options
        var opt =  document.createElement("option");
          opt.value = "";
          opt.selected = true;
          opt.disabled = true;
          opt.hidden = true;
          var sizeVal = document.createTextNode("Sizes");
          opt.appendChild(sizeVal);
          select.appendChild(opt);
        for(var j =0 ; j<item[i].itemSizes.length ; j++){
          var opt =  document.createElement("option");
          var sizee = item[i].itemSizes[j];
          opt.value = sizee;
          var sizeVal = document.createTextNode(sizee);
          opt.appendChild(sizeVal);
          select.appendChild(opt);
    
        }
    
        //Add button
        var butt = document.createElement("button");
        butt.type = "button";
        var addca = document.createTextNode("Add to Cart");
        butt.appendChild(addca)
        butt.value= "Add to Cart";
        butt.className= "addcart";
    
    
    
        aa.appendChild(tit);
        aaa.appendChild(pic);
        prod.appendChild(aaa);
        down.appendChild(aa);
        down.appendChild(price);
        down.appendChild(des);
        down.appendChild(sp);
        siz.appendChild(select);
        
        cart.appendChild(siz);
        cart.appendChild(butt);
        
    
        prod.appendChild(down);
        prod.appendChild(cart);
        cont.appendChild(prod);
        position.appendChild(cont);
        }
  
      }
      
    }
    
  
  
  
    
    
  
    
  }
    



//items
item=[{
itemId: 1,
itemName:'Printed Blue T-Shirt',
itemDesc:'Printed pattern T-shirt',
itemPrice: 290,
itemReviews: 25,
itemSizes:['S','M','L'],
itemCat: 1
},

{
  itemId: 2,
  itemName:'Orange Printed T-Shirt',
  itemDesc:'Orange Printed T-Shirt.',
  itemPrice: 280,
  itemReviews: 35,
  itemSizes:['M','L'],
  itemCat: 1
  },

{
  itemId: 3,
  itemName:'Plain T-Shirt',
  itemDesc:'Plain White and Green T-Shirt.',
  itemPrice: 270,
  itemReviews: 40,
  itemSizes:['XS','M','XL'],
  itemCat: 1
  },

{
  itemId: 4,
  itemName:'Green Pants',
  itemDesc:'Green pants for woman.',
  itemPrice: 310,
  itemReviews: 38,
  itemSizes:['XL'],
  itemCat: 2
  },

{
  itemId: 5,
  itemName:'Black Jeans',
  itemDesc:'Black Jeans for women.',
  itemPrice: 425,
  itemReviews: 51,
  itemSizes:['S','M','L'],
  itemCat: 2
  },

{
  itemId: 6,
  itemName:'Pink Pants',
  itemDesc:'Pink Pants for women.',
  itemPrice: 410,
  itemReviews: 7,
  itemSizes:[],
  itemCat: 2
  },

{
  itemId: 7,
  itemName:'Plain Blue T-Shirt',
  itemDesc:'Plain Blue Women T-Shirt.',
  itemPrice: 320,
  itemReviews: 43,
  itemSizes:['XS','M','XL'],
  itemCat: 1
  
  },

{
  itemId: 8,
  itemName:'Baby-Blue T-Shirt',
  itemDesc:'Baby-Blue Women T-Shirt.',
  itemPrice: 210,
  itemReviews: 11,
  itemSizes:['S','XL'],
  itemCat: 1
  
},


{
  itemId: 9,
  itemName:'Blue Jeans',
  itemDesc:'Blue Jeans for Women.',
  itemPrice: 350,
  itemReviews: 39,
  itemSizes:['S','M'],
  itemCat: 2
  
},




{
    itemId: 10,
    itemName:'Red Pants',
    itemDesc:'Red Pants for Women',
    itemPrice: 500,
    itemReviews: 14,
    itemSizes:['XS','S','L'],
    itemCat: 2
    
  },


{
  itemId: 11,
  itemName:'White Pants',
  itemDesc:'White Pants for Women',
  itemPrice: 365,
  itemReviews: 31,
  itemSizes:['XS','S','L'],
  itemCat: 2
  
},

            
  












];